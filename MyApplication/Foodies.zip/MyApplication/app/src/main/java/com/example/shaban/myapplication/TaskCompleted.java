package com.example.shaban.myapplication;

import java.util.ArrayList;

public interface TaskCompleted {
    public void onTaskComplete(ArrayList<String> result);
}
