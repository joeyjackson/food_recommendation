package com.example.shaban.myapplication;

import java.util.ArrayList;

public interface TaskCompletedCatalog {
    public void onTaskComplete(ArrayList<ArrayList<String>> result);
}